﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.SessionState;
using Web.ScpecFlow.Models;

namespace Web.ScpecFlow.Controllers
{
    public class LoginController : Controller 
    {
        public ActionResult Login()
        {
            ViewBag.Title = "Login";
            return View();
        }

        //
        // GET: /Login/
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginDetails loginDetails)
        {
            if (ModelState.IsValid)
            {
                if (loginDetails != null &&
                    loginDetails.Password.Length > 2 &&
                    string.Equals(loginDetails.UserName, "Sumit"))
                {
                    Session["UserName"] = loginDetails.UserName;
                    return RedirectToAction("UserDashBoard");
                }
            }

            return View(loginDetails);
        }

        public ActionResult UserDashBoard()
        {
            if (Session["UserName"] != null)
            {
                ViewBag.MyName = "DashBoard";
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }


    }
}
