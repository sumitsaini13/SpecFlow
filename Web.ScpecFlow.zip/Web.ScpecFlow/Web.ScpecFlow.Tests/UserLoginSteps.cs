﻿using NUnit.Framework;
using System;
using System.Web.Mvc;
using TechTalk.SpecFlow;
using Web.ScpecFlow.Controllers;

namespace Web.ScpecFlow.Tests
{
    [Binding]
    public class UserLoginSteps
    {
        ActionResult result;
        LoginController controller;

        [When(@"the user goes to the login user screen")]
        public void WhenTheUserGoesToTheLoginUserScreen()
        {
            controller = new LoginController();
            result = controller.Login();
        }
        
        [Then(@"the login user view should be displayed")]
        public void ThenTheLoginUserViewShouldBeDisplayed()
        {
            Assert.IsInstanceOf<ViewResult>(result);
            Assert.IsEmpty(((ViewResult)result).ViewName);
            Assert.AreEqual("Login", controller.ViewBag.Title, "Page Title is wrong");
        }
    }
}
