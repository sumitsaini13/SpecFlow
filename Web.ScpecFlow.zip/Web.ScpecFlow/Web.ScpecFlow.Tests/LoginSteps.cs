﻿using NUnit.Framework;
using System;
using System.IO;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.SessionState;
using TechTalk.SpecFlow;
using Web.ScpecFlow.Controllers;
using Web.ScpecFlow.Models;

namespace Web.ScpecFlow.Tests
{
    [Binding]
    public class LoginSteps
    {

        LoginController controller;
        ActionResult result;
        LoginDetails loginDetails;

        [Given(@"User has entered all the required information")]
        public void GivenUserHasEnteredAllTheRequiredInformation()
        {
            loginDetails = new LoginDetails()
            {
                UserName = "Sumit",
                Password = "1123456"
            };

            var fakeHttpContext = MockHelpers.FakeHttpContext();

            controller = new LoginController();
            controller.ControllerContext = new ControllerContext(new HttpContextWrapper(fakeHttpContext), new RouteData(), controller);
        }
        
        [When(@"User clicks on Login button")]
        public void WhenUserClicksOnLoginButton()
        {
            result = controller.Login(loginDetails);
        }
        
        [Then(@"User should be redirected to UserDashBoard screen")]
        public void ThenUserShouldBeRedirectedToUserDashBoardScreen()
        {
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<RedirectToRouteResult>(result);
            var res = result as RedirectToRouteResult;
            Assert.AreEqual("UserDashBoard", res.RouteValues["action"], "Action Name is not correct");
        }
    }
}
